from .mimose import DeviceMimose
